# -*- coding: utf-8 -*-
"""
default.py
Entry point for the Pluto TV Free Kodi addon.

This version lists Pluto TV's live channels inside Kodi, but instead of
resolving and playing a stream URL natively, selecting a channel opens
that channel's page on pluto.tv in the device's default web browser
(via an Android intent). Kodi itself never builds, stitches, or plays
a video stream -- it just hands off to the browser, the same as if you
tapped a link.
"""

import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Make the resources/lib folder importable
sys.path.insert(0, xbmcaddon.Addon(id="plugin.video.pluto_free").getAddonInfo("path") + "/resources/lib")

from pluto_api import PlutoClient, PlutoAPIError  # noqa: E402

ADDON = xbmcaddon.Addon(id="plugin.video.pluto_free")
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

PLUTO_LIVE_TV_URL = "https://pluto.tv/live-tv"


def log(msg):
    xbmc.log("Pluto Free: %s" % msg, xbmc.LOGINFO)


def get_url(**kwargs):
    """Build a plugin:// URL with URL-encoded values."""
    parts = []
    for key, value in kwargs.items():
        parts.append("%s=%s" % (key, urllib.parse.quote(str(value), safe='')))
    return "{0}?{1}".format(BASE_URL, "&".join(parts))


def channel_web_url(channel):
    """The pluto.tv page for a specific channel, if we have a slug.
    Falls back to the general live TV guide page if no slug is available."""
    slug = channel.get("slug")
    if slug:
        return "https://pluto.tv/live-tv/%s" % slug
    return PLUTO_LIVE_TV_URL


def open_in_browser(url):
    """Hand off to the device's default web browser via an Android intent.
    Kodi does not fetch, build, or play any video itself here."""
    log("Opening in browser: %s" % url)
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","","%s")' % url)


def list_channels():
    xbmcplugin.setContent(ADDON_HANDLE, "videos")

    client = PlutoClient()
    try:
        channels = client.get_channels()
    except PlutoAPIError as e:
        xbmc.log("Pluto Free: %s" % e, xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Pluto TV Free - Error", str(e))
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return
    except Exception as e:
        xbmc.log("Pluto Free: unexpected error: %s" % e, xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Pluto TV Free - Unexpected Error", "%s: %s" % (type(e).__name__, e))
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    if not channels:
        xbmcgui.Dialog().ok(
            "Pluto TV Free",
            "Connected to Pluto OK, but the channel list came back empty. "
            "session_token=%s" % ("yes" if client.session_token else "no")
        )
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    # Always offer a shortcut straight to Pluto's live TV guide
    guide_item = xbmcgui.ListItem(label="Open Pluto TV Live Guide (browser)")
    guide_item.setInfo("video", {"title": "Open Pluto TV Live Guide", "mediatype": "video"})
    guide_url = get_url(action="browse", weburl=PLUTO_LIVE_TV_URL)
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, guide_url, guide_item, isFolder=False)

    for ch in channels:
        list_item = xbmcgui.ListItem(label=ch["name"])
        list_item.setInfo("video", {"title": ch["name"], "mediatype": "video"})
        if ch.get("logo"):
            list_item.setArt({"thumb": ch["logo"], "icon": ch["logo"], "fanart": ch["logo"]})

        web_url = channel_web_url(ch)
        url = get_url(action="browse", weburl=web_url)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def browse_channel(web_url):
    open_in_browser(web_url)
    # This isn't a playable Kodi item -- we just triggered a browser
    # hand-off. Tell Kodi the "play" didn't resolve to a Kodi-playable
    # stream so it doesn't sit there with a spinner.
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, listitem=xbmcgui.ListItem())


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    if action == "browse":
        web_url = urllib.parse.unquote(params["weburl"])
        browse_channel(web_url)
    else:
        list_channels()


if __name__ == "__main__":
    # sys.argv[2] is the query string (with leading '?'), strip it
    query = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2] else ""
    router(query)
