# Pluto TV Free — Kodi Addon

A Kodi video addon that lists Pluto TV's free, ad-supported live channels
and plays them, using Pluto's own public web API (no account/login needed
for the free live lineup).

## What was wrong with the original repo

The repo had three files sitting loose at the root:

- `addon.xml` — declared `library="default.py"` and addon id `plugin.video.pluto_free`
- `plugin.video.pluto.free` — a stray file, not a folder, named almost like the
  addon id (note the `.free` vs `_free` mismatch too)
- `python` — the actual addon code, but named `python` instead of `default.py`,
  and it pulled a generic third-party IPTV playlist, not real Pluto TV channels

Kodi requires the addon folder name to match `addon.xml`'s `id`, and the
script file referenced by `library="..."` to exist with that exact name,
inside that folder. None of that lined up, so Kodi couldn't load it.

## What's fixed here

```
plugin.video.pluto_free/
├── addon.xml
├── default.py
└── resources/
    ├── images/icon.png
    └── lib/pluto_api.py
```

- `default.py` is the addon entry point (matches `library="default.py"`).
- `resources/lib/pluto_api.py` talks to Pluto's real API:
  1. `GET boot.pluto.tv/v4/start` → gets a session token
  2. `GET service-channels.clusters.pluto.tv/v2/guide/channels` (with that
     token as a Bearer header) → real, current Pluto channel list
  3. Builds each channel's HLS stream URL from Pluto's `stitcher.pluto.tv`
     service using that same session token

## How to publish it to your repo

1. In your GitHub repo, delete the old `addon.xml`, `plugin.video.pluto.free`,
   and `python` files from the root.
2. Add the `plugin.video.pluto_free/` folder (with everything inside it) to
   the repo root, so the structure looks like:
   ```
   your-repo/
   └── plugin.video.pluto_free/
       ├── addon.xml
       ├── default.py
       └── resources/...
   ```
3. Commit and push.

## How to install in Kodi

**Option A — zip install (easiest):**
1. Zip the `plugin.video.pluto_free` folder (zip the folder itself, not just its contents).
2. In Kodi: Settings → Add-ons → Install from zip file → pick the zip.

**Option B — via repo:**
Point Kodi's file source at your GitHub repo's raw folder URL and install
from there, or use a Kodi repository structure if you want this addon to
auto-update.

## If a channel doesn't play

Pluto periodically tweaks the exact query parameters its stitcher service
expects on stream URLs. If channels list but won't play, the fix is almost
always in `_build_stream_url()` in `pluto_api.py` — capture the network
request your browser makes when playing a channel on pluto.tv and compare
the query params to what's being sent there.
